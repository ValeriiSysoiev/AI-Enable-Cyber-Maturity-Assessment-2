from __future__ import annotations
from typing import List, Optional, Literal, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timezone
import uuid
import hashlib
import json

Role = Literal["lead", "member"]

class Engagement(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    client_code: Optional[str] = None
    created_by: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Membership(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    engagement_id: str
    user_email: str
    role: Role = "member"
    added_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Assessment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    engagement_id: str
    framework: Literal["NIST-CSF", "ISO-27001", "CIS", "Custom"] = "NIST-CSF"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Question(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    assessment_id: str
    text: str
    pillar: Optional[str] = None

class Response(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    assessment_id: str
    question_id: str
    answer: str

class Finding(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    assessment_id: str
    title: str
    evidence: Optional[str] = None
    severity: Literal["low", "medium", "high"] = "medium"
    area: Optional[str] = None  # e.g., Identity, Data, SecOps

class Recommendation(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    assessment_id: str
    title: str
    rationale: Optional[str] = None
    priority: Literal["P1", "P2", "P3"] = "P2"
    effort: Literal["S", "M", "L"] = "M"
    timeline_weeks: Optional[int] = None

class RunLog(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    assessment_id: str
    agent: str  # "DocAnalyzer" | "GapRecommender" | etc.
    input_preview: Optional[str] = None
    output_preview: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Document(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    engagement_id: str
    filename: str
    content_type: Optional[str] = None
    size: int = 0
    path: str  # absolute or repo-root relative path on disk
    uploaded_by: str
    uploaded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Evidence(BaseModel):
    """Evidence file record with checksum and PII detection"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    engagement_id: str
    blob_path: str  # Path in blob storage: engagements/{engagementId}/evidence/{uuid}/{filename}
    filename: str
    checksum_sha256: str  # Server-computed SHA-256 checksum
    size: int  # File size in bytes
    mime_type: str  # Content type
    uploaded_by: str  # User email who uploaded
    uploaded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    pii_flag: bool = False  # True if PII heuristics detected potential PII
    
    # Optional links to assessment items (many-to-many)
    linked_items: List[Dict[str, str]] = Field(default_factory=list)  # [{"itemType": "assessment", "itemId": "uuid"}]

class EmbeddingDocument(BaseModel):
    """Vector embedding document for RAG storage"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    engagement_id: str
    doc_id: str  # Reference to original Document
    chunk_id: str  # Unique identifier for this chunk
    vector: List[float]  # Embedding vector
    text: str  # Text content of the chunk
    metadata: Dict[str, Any] = Field(default_factory=dict)  # Additional metadata
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    # Chunk-specific metadata
    chunk_index: int = 0
    chunk_start: int = 0
    chunk_end: int = 0
    token_count: Optional[int] = None
    
    # Source document metadata
    filename: str = ""
    uploaded_by: str = ""
    uploaded_at: Optional[datetime] = None
    
    # Embedding metadata
    model: str = ""
    embedding_created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ServiceBusMessage(BaseModel):
    """Service Bus message for orchestration queuing"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: str  # Message type for routing (e.g., "ingest", "minutes", "score")
    payload: Dict[str, Any]  # Message payload
    correlation_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    # Retry handling
    retry_count: int = 0
    max_retries: int = 3
    
    # Dead letter queue support
    is_dead_lettered: bool = False
    dead_letter_reason: Optional[str] = None
    
    # Processing metadata
    processed_at: Optional[datetime] = None
    processed_by: Optional[str] = None
    
    # Engagement context
    engagement_id: Optional[str] = None
    user_email: Optional[str] = None


class QueueConfig(BaseModel):
    """Queue configuration with DLQ support"""
    name: str
    max_delivery_count: int = 3
    ttl_seconds: int = 3600  # 1 hour
    enable_dead_letter_queue: bool = True
    dead_letter_queue_name: str = Field(default_factory=lambda: "")
    
    def __post_init__(self):
        if not self.dead_letter_queue_name and self.enable_dead_letter_queue:
            self.dead_letter_queue_name = f"{self.name}-dlq"

class CSFSubcategory(BaseModel):
    """CSF 2.0 Subcategory model"""
    id: str
    function_id: str
    category_id: str
    title: str
    description: str

class CSFCategory(BaseModel):
    """CSF 2.0 Category model"""
    id: str
    function_id: str
    title: str
    description: str
    subcategories: List[CSFSubcategory] = Field(default_factory=list)

class CSFFunction(BaseModel):
    """CSF 2.0 Function model"""
    id: str
    title: str
    description: str
    categories: List[CSFCategory] = Field(default_factory=list)

class ConsentRecord(BaseModel):
    """Attendee consent record for workshops"""
    by: str  # User who gave consent (typically same as attendee email)
    user_id: str  # User ID who gave consent
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class WorkshopAttendee(BaseModel):
    """Workshop attendee information"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # User identifier
    email: str
    role: str  # attendee role in workshop
    consent: Optional[ConsentRecord] = None

class Workshop(BaseModel):
    """Workshop for engagement activities requiring consent"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    engagement_id: str
    title: str
    start_ts: Optional[datetime] = None
    attendees: List[WorkshopAttendee] = Field(default_factory=list)
    created_by: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started: bool = False
    started_at: Optional[datetime] = None

class MinutesSection(BaseModel):
    """Structured minutes section with attendees, decisions, actions, and questions"""
    attendees: List[str] = Field(default_factory=list)
    decisions: List[str] = Field(default_factory=list)
    actions: List[str] = Field(default_factory=list)
    questions: List[str] = Field(default_factory=list)

class Minutes(BaseModel):
    """Workshop minutes model"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    workshop_id: str
    status: Literal["draft", "published"] = "draft"
    sections: MinutesSection = Field(default_factory=MinutesSection)
    generated_by: Literal["agent", "human"] = "agent"
    published_at: Optional[datetime] = None
    content_hash: Optional[str] = None
    parent_id: Optional[str] = None  # For versioning/revision tracking
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_by: str = ""
    
    def compute_content_hash(self) -> str:
        """
        Compute SHA-256 hash of normalized content for immutability verification.
        Includes sections data and workshop_id for uniqueness.
        """
        # Create normalized content for hashing
        normalized_content = {
            "workshop_id": self.workshop_id,
            "sections": {
                "attendees": sorted(self.sections.attendees),  # Sort for consistency
                "decisions": sorted(self.sections.decisions),
                "actions": sorted(self.sections.actions),
                "questions": sorted(self.sections.questions)
            }
        }
        
        # Convert to JSON with sorted keys for consistent hashing
        content_json = json.dumps(normalized_content, sort_keys=True, separators=(',', ':'))
        
        # Compute SHA-256 hash
        return hashlib.sha256(content_json.encode('utf-8')).hexdigest()
    
    def validate_content_integrity(self) -> bool:
        """
        Validate that current content matches the stored content hash.
        Returns True if valid or no hash is set (draft state).
        """
        if not self.content_hash:
            return True  # No hash means draft state - always valid
        
        current_hash = self.compute_content_hash()
        return current_hash == self.content_hash
    
    def is_published(self) -> bool:
        """Check if minutes are in published state"""
        return self.status == "published"
    
    def can_edit(self) -> bool:
        """Check if minutes can be edited (only drafts)"""
        return self.status == "draft"

class ChatMessage(BaseModel):
    """Chat message for orchestrator shell interface"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    engagement_id: str
    message: str
    sender: Literal["user", "agent"] = "user"
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    correlation_id: Optional[str] = None

class RunCard(BaseModel):
    """Orchestrator command execution record"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    engagement_id: str
    command: str  # Original command text (e.g., "/ingest docs")
    inputs: Dict[str, Any] = Field(default_factory=dict)  # Parsed command parameters
    outputs: Optional[Dict[str, Any]] = None  # Command execution results
    status: Literal["queued", "running", "done", "error"] = "queued"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    created_by: str  # User email
    citations: Optional[List[str]] = None  # Document references
