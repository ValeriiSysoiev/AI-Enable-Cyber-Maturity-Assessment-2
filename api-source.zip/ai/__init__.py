# AI module for LLM client and orchestration
