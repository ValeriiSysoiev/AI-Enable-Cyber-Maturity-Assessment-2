# Storage factory module
# This is a stub to prevent import errors

def create_storage():
    """Factory method to create storage instance"""
    pass